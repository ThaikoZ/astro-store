<?php
/**
 * Plugin Name: Astro Checkout UI
 * Description: Stripe Checkout-style blank WooCommerce checkout (split summary + form).
 * Author: Astro Store
 *
 * Install:
 *   1. Copy this file to wp-content/mu-plugins/astro-checkout-ui.php
 *   2. Copy the folder wp-content/mu-plugins/astro-checkout-ui/ (css, js, templates)
 *
 * Works alongside astro-headless-checkout.php (session handoff + Astro return URL).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'ASTRO_CHECKOUT_UI_DIR', __DIR__ . '/astro-checkout-ui' );
define( 'ASTRO_CHECKOUT_UI_URL', content_url( 'mu-plugins/astro-checkout-ui' ) );

/**
 * Whether the blank checkout UI should replace the theme template.
 */
function astro_checkout_ui_should_load(): bool {
	if ( is_admin() || ! function_exists( 'is_checkout' ) ) {
		return false;
	}

	if ( ! is_checkout() ) {
		return false;
	}

	if ( function_exists( 'is_wc_endpoint_url' ) && is_wc_endpoint_url() ) {
		return false;
	}

	if ( function_exists( 'is_order_received_page' ) && is_order_received_page() ) {
		return false;
	}

	return true;
}

/**
 * Swap the theme template for our blank checkout shell.
 */
add_filter(
	'template_include',
	static function ( $template ) {
		if ( ! astro_checkout_ui_should_load() ) {
			return $template;
		}

		$blank = ASTRO_CHECKOUT_UI_DIR . '/template-checkout.php';
		return file_exists( $blank ) ? $blank : $template;
	},
	99
);

/**
 * Prefer MU-plugin Woo templates (form-checkout, review-order).
 */
add_filter(
	'woocommerce_locate_template',
	static function ( $template, $template_name, $template_path ) {
		if ( ! astro_checkout_ui_should_load() ) {
			return $template;
		}

		$override = ASTRO_CHECKOUT_UI_DIR . '/woocommerce/' . $template_name;
		return file_exists( $override ) ? $override : $template;
	},
	20,
	3
);

/**
 * Assets only on blank checkout.
 */
add_action(
	'wp_enqueue_scripts',
	static function (): void {
		if ( ! astro_checkout_ui_should_load() ) {
			return;
		}

		wp_enqueue_style(
			'astro-checkout-fonts',
			'https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap',
			array(),
			null
		);

		$css_path = ASTRO_CHECKOUT_UI_DIR . '/checkout.css';
		$js_path  = ASTRO_CHECKOUT_UI_DIR . '/checkout.js';
		$css_ver  = file_exists( $css_path ) ? (string) filemtime( $css_path ) : '2.0.0';
		$js_ver   = file_exists( $js_path ) ? (string) filemtime( $js_path ) : '2.0.0';

		wp_enqueue_style(
			'astro-checkout-ui',
			ASTRO_CHECKOUT_UI_URL . '/checkout.css',
			array( 'astro-checkout-fonts' ),
			$css_ver
		);

		wp_enqueue_script(
			'astro-checkout-ui',
			ASTRO_CHECKOUT_UI_URL . '/checkout.js',
			array(),
			$js_ver,
			true
		);
	},
	100
);

add_filter(
	'body_class',
	static function ( array $classes ): array {
		if ( astro_checkout_ui_should_load() ) {
			$classes[] = 'astro-checkout';
			$classes[] = 'astro-pay';
		}
		return $classes;
	}
);

add_filter(
	'show_admin_bar',
	static function ( $show ) {
		return astro_checkout_ui_should_load() ? false : $show;
	}
);

/**
 * Place-order CTA: Zapłać {total}
 */
add_filter(
	'woocommerce_order_button_text',
	static function () {
		if ( ! WC()->cart ) {
			return 'Zapłać';
		}
		$total = wp_strip_all_tags( wc_price( WC()->cart->get_total( 'edit' ) ) );
		return $total !== '' ? 'Zapłać ' . $total : 'Zapłać';
	}
);

/**
 * Keep hero totals in sync when Woo refreshes the order review via AJAX.
 */
add_filter(
	'woocommerce_update_order_review_fragments',
	static function ( $fragments ) {
		if ( ! astro_checkout_ui_should_load() || ! WC()->cart ) {
			return $fragments;
		}

		$total_html = wp_kses_post( WC()->cart->get_total() );
		// jQuery replaceWith runs per matched node; keep the same class on each total chip.
		$fragments['.astro-pay-total-hero__value'] = '<span class="astro-pay-total-hero__value">' . $total_html . '</span>';

		return $fragments;
	}
);

/**
 * Tighter Stripe-like field set for digital-friendly checkout.
 */
add_filter(
	'woocommerce_checkout_fields',
	static function ( $fields ) {
		if ( ! astro_checkout_ui_should_load() ) {
			return $fields;
		}

		unset( $fields['billing']['billing_company'] );
		unset( $fields['billing']['billing_phone'] );
		unset( $fields['order']['order_comments'] );

		if ( isset( $fields['billing']['billing_email'] ) ) {
			$fields['billing']['billing_email']['priority'] = 5;
			$fields['billing']['billing_email']['label']    = 'Email';
			$fields['billing']['billing_email']['class']    = array( 'form-row-wide', 'astro-pay-field-email' );
		}

		if ( isset( $fields['billing']['billing_first_name'] ) ) {
			$fields['billing']['billing_first_name']['label'] = 'Imię';
		}
		if ( isset( $fields['billing']['billing_last_name'] ) ) {
			$fields['billing']['billing_last_name']['label'] = 'Nazwisko';
		}
		if ( isset( $fields['billing']['billing_address_1'] ) ) {
			$fields['billing']['billing_address_1']['label']       = 'Adres';
			$fields['billing']['billing_address_1']['placeholder'] = 'Ulica i numer';
		}
		if ( isset( $fields['billing']['billing_address_2'] ) ) {
			$fields['billing']['billing_address_2']['label'] = 'Mieszkanie, lokal (opcjonalnie)';
		}
		if ( isset( $fields['billing']['billing_city'] ) ) {
			$fields['billing']['billing_city']['label'] = 'Miasto';
		}
		if ( isset( $fields['billing']['billing_postcode'] ) ) {
			$fields['billing']['billing_postcode']['label'] = 'Kod pocztowy';
		}
		if ( isset( $fields['billing']['billing_country'] ) ) {
			$fields['billing']['billing_country']['label'] = 'Kraj';
		}
		if ( isset( $fields['billing']['billing_state'] ) ) {
			$fields['billing']['billing_state']['label'] = 'Województwo';
		}

		return $fields;
	},
	20
);

/**
 * Soft-remove common theme chrome hooks.
 */
add_action(
	'wp',
	static function (): void {
		if ( ! astro_checkout_ui_should_load() ) {
			return;
		}

		remove_all_actions( 'storefront_header' );
		remove_all_actions( 'storefront_footer' );
		remove_all_actions( 'generate_header' );
		remove_all_actions( 'generate_footer' );
		remove_all_actions( 'astra_header' );
		remove_all_actions( 'astra_footer' );
	},
	20
);
