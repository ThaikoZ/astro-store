<?php
/**
 * Stripe-style checkout form override.
 *
 * Left: order summary. Right: customer fields + payment.
 * Payment is intentionally NOT rendered via woocommerce_checkout_order_review
 * (that action also prints the payment block in core).
 *
 * @package AstroCheckoutUI
 * @version 9.4.0
 */

defined( 'ABSPATH' ) || exit;

$brand_url = home_url( '/' );
if ( function_exists( 'astro_headless_checkout_app_origin' ) ) {
	$astro_origin = astro_headless_checkout_app_origin();
	if ( $astro_origin !== '' ) {
		$brand_url = trailingslashit( $astro_origin );
	}
}

$cart_total = ( WC()->cart ) ? WC()->cart->get_total() : '';

do_action( 'woocommerce_before_checkout_form', $checkout );

if ( ! $checkout->is_registration_enabled() && $checkout->is_registration_required() && ! is_user_logged_in() ) {
	echo esc_html( apply_filters( 'woocommerce_checkout_must_be_logged_in_message', __( 'You must be logged in to checkout.', 'woocommerce' ) ) );
	return;
}
?>

<form name="checkout" method="post" class="checkout woocommerce-checkout astro-pay-checkout" action="<?php echo esc_url( wc_get_checkout_url() ); ?>" enctype="multipart/form-data" aria-label="<?php echo esc_attr__( 'Checkout', 'woocommerce' ); ?>">

	<div class="astro-pay-layout">

		<aside class="astro-pay-summary" aria-label="<?php echo esc_attr__( 'Podsumowanie zamówienia', 'woocommerce' ); ?>">
			<div class="astro-pay-summary__inner">
				<a class="astro-pay-back" href="<?php echo esc_url( $brand_url ); ?>">
					<span class="astro-pay-back__arrow" aria-hidden="true">&larr;</span>
					<span class="astro-pay-back__brand">Klaudia Jaranowska</span>
				</a>

				<p class="astro-pay-eyebrow"><?php esc_html_e( 'Zapłać', 'woocommerce' ); ?></p>
				<p class="astro-pay-total-hero">
					<span class="astro-pay-total-hero__value"><?php echo wp_kses_post( $cart_total ); ?></span>
				</p>

				<button type="button" class="astro-pay-summary-toggle" data-astro-summary-toggle aria-expanded="false">
					<span class="astro-pay-summary-toggle__label" data-astro-summary-toggle-label>
						<?php esc_html_e( 'Pokaż podsumowanie', 'woocommerce' ); ?>
					</span>
					<span class="astro-pay-summary-toggle__total astro-pay-total-hero__value"><?php echo wp_kses_post( $cart_total ); ?></span>
					<span class="astro-pay-summary-toggle__chevron" aria-hidden="true"></span>
				</button>

				<div class="astro-pay-summary__body" data-astro-summary-body hidden>
					<?php do_action( 'woocommerce_checkout_before_order_review_heading' ); ?>
					<?php do_action( 'woocommerce_checkout_before_order_review' ); ?>

					<div id="order_review" class="woocommerce-checkout-review-order astro-pay-review">
						<?php woocommerce_order_review(); ?>
					</div>

					<?php do_action( 'woocommerce_checkout_after_order_review' ); ?>

					<p class="astro-pay-summary__legal">
						<?php
						if ( function_exists( 'wc_terms_and_conditions_page_id' ) && wc_terms_and_conditions_page_id() ) {
							echo wp_kses_post(
								sprintf(
									/* translators: %s: terms page link */
									__( 'Kontynuując akceptujesz %s.', 'woocommerce' ),
									'<a href="' . esc_url( get_permalink( wc_terms_and_conditions_page_id() ) ) . '" target="_blank" rel="noopener">' . esc_html__( 'regulamin', 'woocommerce' ) . '</a>'
								)
							);
						} else {
							esc_html_e( 'Bezpieczna płatność', 'woocommerce' );
						}
						?>
					</p>
				</div>
			</div>
		</aside>

		<section class="astro-pay-form" aria-label="<?php echo esc_attr__( 'Dane i płatność', 'woocommerce' ); ?>">
			<div class="astro-pay-form__inner">
				<?php if ( $checkout->get_checkout_fields() ) : ?>

					<?php do_action( 'woocommerce_checkout_before_customer_details' ); ?>

					<div class="astro-pay-section" id="customer_details">
						<h2 class="astro-pay-section__title"><?php esc_html_e( 'Kontakt', 'woocommerce' ); ?></h2>

						<div class="astro-pay-billing col2-set">
							<?php do_action( 'woocommerce_checkout_billing' ); ?>
						</div>

						<?php if ( WC()->cart && WC()->cart->needs_shipping_address() ) : ?>
							<div class="astro-pay-shipping">
								<h2 class="astro-pay-section__title"><?php esc_html_e( 'Dostawa', 'woocommerce' ); ?></h2>
								<?php do_action( 'woocommerce_checkout_shipping' ); ?>
							</div>
						<?php endif; ?>
					</div>

					<?php do_action( 'woocommerce_checkout_after_customer_details' ); ?>

				<?php endif; ?>

				<div class="astro-pay-section astro-pay-section--payment">
					<h2 class="astro-pay-section__title"><?php esc_html_e( 'Płatność', 'woocommerce' ); ?></h2>
					<?php woocommerce_checkout_payment(); ?>
				</div>
			</div>
		</section>

	</div>

</form>

<?php
do_action( 'woocommerce_after_checkout_form', $checkout );
