(function () {
	function ready(fn) {
		if (document.readyState !== 'loading') fn();
		else document.addEventListener('DOMContentLoaded', fn);
	}

	ready(function () {
		var toggle = document.querySelector('[data-astro-summary-toggle]');
		var body = document.querySelector('[data-astro-summary-body]');
		var label = document.querySelector('[data-astro-summary-toggle-label]');
		if (!toggle || !body) return;

		var showText = label ? label.textContent : 'Pokaż podsumowanie';
		var hideText = 'Ukryj podsumowanie';

		function setOpen(open) {
			toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
			if (open) body.removeAttribute('hidden');
			else body.setAttribute('hidden', '');
			if (label) label.textContent = open ? hideText : showText;
			document.body.classList.toggle('astro-summary-open', open);
		}

		// Desktop: summary always visible via CSS; mobile toggle controls [hidden].
		function syncToViewport() {
			if (window.matchMedia('(min-width: 900px)').matches) {
				body.removeAttribute('hidden');
				toggle.setAttribute('aria-expanded', 'true');
				document.body.classList.add('astro-summary-open');
			} else {
				setOpen(toggle.getAttribute('aria-expanded') === 'true');
			}
		}

		toggle.addEventListener('click', function () {
			if (window.matchMedia('(min-width: 900px)').matches) return;
			setOpen(toggle.getAttribute('aria-expanded') !== 'true');
		});

		window.addEventListener('resize', syncToViewport);
		syncToViewport();
	});
})();
